PERBAIKAN STOCKFISHLAB - HTTP 403

Penyebab: versi sebelumnya mengunduh engine dari CDN saat aplikasi dibuka. Server CDN mengembalikan HTTP 403.

Perbaikan: engine Stockfish 19 Lite Single-threaded dimasukkan ke APK saat GitHub Actions melakukan build. Aplikasi tidak perlu mengunduh engine saat pertama dibuka.

LANGKAH:
1. Upload ulang StockfishLab_Android_Project.zip ke repository GitHub, timpa file ZIP lama.
2. Buka .github/workflows/build.yml, tekan Edit, ganti seluruh isinya dengan file build.yml yang disediakan terpisah dalam paket perbaikan ini.
3. Commit changes.
4. Buka Actions dan tunggu workflow selesai dengan centang hijau.
5. Download Artifact StockfishLab-APK, ekstrak, lalu instal app-debug.apk.

Catatan: ZIP proyek ini belum berisi binary engine. Workflow akan mengambil paket resmi stockfish@19.0.1 dari npm dan menaruh dua file engine ke dalam APK saat build. Jadi APK hasil build sudah membawa engine dan tidak mengunduhnya lagi saat aplikasi dibuka.
