# Stockfish Lab — Proyek Android

Proyek Android sederhana untuk menganalisis posisi catur secara mandiri memakai Stockfish 19 Lite Single-Threaded.

## Fitur

- Papan catur dari posisi FEN.
- Analisis Stockfish dengan pilihan Depth 8, 12, 16, atau 20.
- Multi-PV untuk menampilkan sampai 3 variasi.
- Langkah terbaik, evaluasi posisi dari sisi putih, depth, waktu, dan principal variations.
- Engine diunduh satu kali lalu disimpan di penyimpanan internal aplikasi.

Aplikasi ini **tidak** membaca layar aplikasi lain, tidak memakai izin Accessibility, tidak membuat jendela mengambang, dan tidak memberi saran tersembunyi saat pertandingan langsung. Masukkan FEN dari posisi latihan atau permainan yang sudah selesai.

## Cara membuat APK

1. Pasang Android Studio di komputer.
2. Ekstrak ZIP ini.
3. Di Android Studio pilih **Open**, lalu pilih folder `stockfish_lab_android` (folder yang berisi `settings.gradle`).
4. Pastikan Android SDK Platform 35 tersedia. Proyek menyertakan skrip `gradlew`/`gradlew.bat` yang mengunduh Gradle 8.13 saat pertama kali dijalankan; Android Studio juga akan mengunduh plugin dan dependensi yang dibutuhkan.
5. Pilih menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. Setelah build berhasil, APK debug ada di `app/build/outputs/apk/debug/app-debug.apk`.

Catatan: ZIP ini adalah **proyek sumber Android Studio**, bukan APK yang sudah dikompilasi. Lingkungan pembuat file ini tidak memiliki Android SDK/Gradle sehingga APK belum bisa dibangun langsung di sini.

## Pemakaian

- Buka aplikasi dan tunggu engine siap.
- Tempel FEN posisi catur di kolom FEN. Posisi awal sudah tersedia sebagai contoh.
- Pilih depth dan jumlah variasi.
- Tekan **Analisis Posisi**.
- Hasil utama menampilkan langkah terbaik dalam format koordinat, misalnya `E2 → E4`.

Depth yang lebih tinggi dapat memerlukan waktu dan daya proses lebih besar, terutama di ponsel. Mulai dari Depth 12.

## Engine & lisensi pihak ketiga

Engine diunduh saat pertama kali aplikasi dibuka dari paket `stockfish` versi `19.0.1`, memakai build `lite-single` (sekitar 1,7 MB untuk JS + WASM menurut dokumentasi paket). Build single-threaded tidak memerlukan cross-origin isolation; versi lite memakai neural network yang lebih kecil dibanding build full.

- Paket dan petunjuk browser: https://www.npmjs.com/package/stockfish
- Sumber: https://github.com/nmrugg/stockfish.js
- Lisensi engine: GNU GPL v3. Lihat `THIRD_PARTY_NOTICES.txt`.

## Kompatibilitas

- Minimum Android: API 24 (Android 7.0).
- Target SDK: API 35.
- Perlu internet saat pertama kali mengunduh engine. Setelah kedua file engine tersimpan, analisis dapat dijalankan tanpa mengunduh ulang.
