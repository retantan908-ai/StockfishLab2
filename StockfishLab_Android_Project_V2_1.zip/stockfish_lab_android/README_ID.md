# Stockfish Lab V2 — Proyek Android

Stockfish Lab V2 adalah aplikasi analisis catur Android berbasis WebView dengan papan interaktif dan Stockfish 19 Lite single-threaded.

## Fitur V2

- Papan catur interaktif: pilih bidak lalu pilih kotak tujuan, atau drag-and-drop.
- Legal move validation melalui `chess.js` (termasuk rokade, en passant, promosi, skak, dan skakmat).
- Pilihan orientasi papan: putih di bawah atau hitam di bawah.
- Analisis Stockfish otomatis setelah langkah jika opsi otomatis aktif, serta tombol analisis manual.
- Langkah terbaik, evaluasi dari sisi putih, depth, waktu, dan hingga 5 variasi PV.
- Tombol menerapkan langkah terbaik pada papan untuk meninjau kelanjutan posisi.
- Undo, redo, reset, riwayat langkah, dan muat FEN.
- Engine Stockfish dan library aturan catur dibundel ke dalam APK saat GitHub Actions build; aplikasi tidak mengunduh engine saat pertama dibuka.

Aplikasi ini ditujukan untuk latihan, analisis posisi sendiri, dan meninjau permainan yang sudah selesai. Aplikasi tidak membaca layar aplikasi lain, tidak membuat overlay, dan tidak memberikan bantuan tersembunyi saat pertandingan langsung.

## Build APK langsung dari HP lewat GitHub Actions

File yang dibutuhkan:

1. `StockfishLab_Android_Project.zip` — ZIP proyek V2.1 ini.
2. `build.yml` — workflow di folder `.github/workflows/` pada repository GitHub.

Langkah:

1. Upload/replace `StockfishLab_Android_Project.zip` di root repository GitHub.
2. Buka `.github/workflows/build.yml`, pilih edit, lalu ganti seluruh isinya dengan file `build.yml` yang disertakan bersama paket V2.
3. Commit perubahan. Workflow ini mengunduh Gradle 8.13 langsung di runner, jadi tidak bergantung pada `gradle-wrapper.jar` yang tidak ada di proyek ZIP.
4. Buka tab **Actions** dan tunggu workflow **Build StockfishLab V2 APK** sampai centang hijau.
5. Buka hasil workflow dan unduh artifact `StockfishLab-V2-APK`.
6. Ekstrak ZIP artifact untuk mendapatkan `app-debug.apk`.

Workflow mengambil paket `stockfish@19.0.1` dan `chess.js@1.4.0` dari npm saat build, menyalin file engine/libraries ke Android assets, lalu mengompilasi APK. Karena itu, build pertama memerlukan akses internet di GitHub Actions. APK hasilnya tidak memerlukan download engine ketika dibuka.

## Build Android Studio

Jika build lewat Android Studio, pastikan dua library juga tersedia di assets sebelum compile:

- `app/src/main/assets/engine/stockfish-19-lite-single.js`
- `app/src/main/assets/engine/stockfish-19-lite-single.wasm`
- `app/src/main/assets/vendor/chess.js`

GitHub Actions workflow mengisi file-file tersebut otomatis. Workflow juga membundel JavaScript ES module menjadi satu file kompatibel WebView agar papan catur selalu ter-render.

## Versi

- versionCode: 2
- versionName: 2.0
- Minimum Android: API 24 (Android 7.0)
- Compile/Target SDK: 35

## Pihak ketiga dan lisensi

- Stockfish.js 19.0.1: GPL-3.0. Sumber dan lisensi: https://github.com/nmrugg/stockfish.js dan https://www.gnu.org/licenses/gpl-3.0.html
- chess.js 1.4.0: BSD-2-Clause. Sumber: https://github.com/jhlywa/chess.js

Lihat juga `THIRD_PARTY_NOTICES.txt`.
