package com.retan.stockfishlab;

import android.app.Activity;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

/** Offline-first WebView shell. Stockfish and chess rules are bundled by the GitHub build workflow. */
public class MainActivity extends Activity {
    private WebView webView;
    private TextView loadingText;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(9, 13, 22));
        getWindow().setNavigationBarColor(Color.rgb(9, 13, 22));
        buildContainer();
        openApp();
    }

    private void buildContainer() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(9, 13, 22));

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        FrameLayout loading = new FrameLayout(this);
        loading.setBackgroundColor(Color.rgb(9, 13, 22));
        loadingText = new TextView(this);
        loadingText.setTextColor(Color.WHITE);
        loadingText.setTextSize(15);
        loadingText.setGravity(Gravity.CENTER);
        loadingText.setText("Membuka Stockfish Lab V2...");
        progressBar = new ProgressBar(this);
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(90, 90, Gravity.CENTER);
        p.bottomMargin = 80;
        loading.addView(progressBar, p);
        FrameLayout.LayoutParams t = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER);
        t.topMargin = 74;
        loading.addView(loadingText, t);
        root.addView(loading, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        loading.setTag("loadingOverlay");
        setContentView(root);
    }

    private void openApp() {
        WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/engine/", path -> openEngineAsset(path))
                .build();

        webView.setWebViewClient(new WebViewClientCompat() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                return assetLoader.shouldInterceptRequest(Uri.parse(url));
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !"appassets.androidplatform.net".equals(request.getUrl().getHost());
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                View loading = ((FrameLayout) webView.getParent()).findViewWithTag("loadingOverlay");
                if (loading != null) loading.setVisibility(View.GONE);
            }
        });
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    private WebResourceResponse openEngineAsset(String path) {
        try {
            InputStream input = getAssets().open("engine/" + path);
            String mime = path.endsWith(".wasm") ? "application/wasm" : "text/javascript";
            return new WebResourceResponse(mime, null, input);
        } catch (IOException e) {
            return new WebResourceResponse("text/plain", "UTF-8", 404,
                    "Not Found", null, new ByteArrayInputStream(new byte[0]));
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
